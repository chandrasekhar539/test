<?php

class PrefixCollision_A_Bar
{
    public static $loaded = true;
}
