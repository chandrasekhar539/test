<?php

namespace ClassesWithParents;

class F
{
    use CTrait;
}
