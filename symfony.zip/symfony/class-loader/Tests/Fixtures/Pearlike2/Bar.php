<?php

class Pearlike2_Bar
{
    public static $loaded = true;
}
