<?php

namespace Acme\DemoLib;

class Foo
{
}
