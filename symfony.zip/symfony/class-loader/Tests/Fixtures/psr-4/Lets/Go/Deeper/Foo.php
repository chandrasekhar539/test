<?php

namespace Acme\DemoLib\Lets\Go\Deeper;

class Foo
{
}
